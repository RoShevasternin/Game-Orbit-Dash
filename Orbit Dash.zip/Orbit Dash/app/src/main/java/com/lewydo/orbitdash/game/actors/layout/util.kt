package com.lewydo.orbitdash.game.actors.layout

enum class AlignH { LEFT, CENTER, RIGHT, SPREAD }
enum class AlignV { TOP, CENTER, BOTTOM, SPREAD }