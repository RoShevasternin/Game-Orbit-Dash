package com.lewydo.orbitdash.game.screens

import com.badlogic.gdx.math.Vector2
import com.badlogic.gdx.scenes.scene2d.Group
import com.lewydo.orbitdash.game.actors.background.AComet
import com.lewydo.orbitdash.game.actors.background.AStarField
import com.lewydo.orbitdash.game.actors.debug.ADebugHud
import com.lewydo.orbitdash.game.actors.debug.addDebugHud
import com.lewydo.orbitdash.game.actors.layout.constraintLayout.AAnchorOf
import com.lewydo.orbitdash.game.actors.layout.constraintLayout.AConstraintLayout
import com.lewydo.orbitdash.game.actors.loader.AMainLoader
import com.lewydo.orbitdash.game.actors.panel.APanelMenu
import com.lewydo.orbitdash.game.actors.panel.APanelMenuState
import com.lewydo.orbitdash.game.utils.Block
import com.lewydo.orbitdash.game.utils.actor.addAndFillActor
import com.lewydo.orbitdash.game.utils.actor.animDelay
import com.lewydo.orbitdash.game.utils.actor.setSize
import com.lewydo.orbitdash.game.utils.advanced.AdvancedScreen
import com.lewydo.orbitdash.game.utils.gdxGame
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.time.Duration.Companion.milliseconds

class MenuScreen : AdvancedScreen() {

    // ------------------------------------------------------------------------
    // Actors
    // ------------------------------------------------------------------------
    private val aStarField by lazy { AStarField(this) }
    private val aComet     by lazy { AComet(this) }
    private val aMain      by lazy { AMainLoader(this, AMainLoader.State.MENU) }

    /** Ланка конвертації root-екрана: не покладаємось на те, що aMain 1:1 з root. */
    private val aTitlesAnchor by lazy { AAnchorOf(aMain.aTitlesAnchor) }

    private val aPanelMenuState by lazy { APanelMenuState(this) }
    private val aPanelMenu      by lazy { APanelMenu(this) }

    // ------------------------------------------------------------------------
    // Lifecycle
    // ------------------------------------------------------------------------
    override fun show() {
        super.show()
    }

    override fun Group.addActorsOnStageUI() {
        addAndFillActor(aStarField)
        addAndFillActor(aComet)
    }

    override fun AConstraintLayout.addActorsOnRootConstraintLayout() {
        add(aMain) { fillParent() }
        addActor(aTitlesAnchor)

        addPanelMenuState()
        addPanelMenu()

        addDebugHud(ADebugHud(this@MenuScreen))
    }

    override fun touchDown(screenX: Int, screenY: Int, pointer: Int, button: Int): Boolean {
        val v = stageUI.screenToStageCoordinates(Vector2(screenX.toFloat(), screenY.toFloat()))
        aStarField.animRippleAt(v.x, v.y)
        return false
    }

    // ------------------------------------------------------------------------
    // Screen Animations
    // ------------------------------------------------------------------------
    override fun animHideScreen(blockEnd: Block) {}
    override fun animShowScreen(blockEnd: Block) {}

    // ------------------------------------------------------------------------
    // Add Actors
    // ------------------------------------------------------------------------
    private fun AConstraintLayout.addPanelMenuState() {
        aPanelMenuState.setSize(1f, 16f)
        add(aPanelMenuState) { centerX(); topToBottom(aTitlesAnchor, 20f) }
    }

    private fun AConstraintLayout.addPanelMenu() {
        aPanelMenu.debug()

        aPanelMenu.setSize(300f, 1f)
        add(aPanelMenu) { centerX(); topToBottom(aPanelMenuState); bottomToBottom(); }
    }

}